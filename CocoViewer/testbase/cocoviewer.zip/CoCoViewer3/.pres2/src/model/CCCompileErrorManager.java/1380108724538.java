package model;

public class CCCompileErrorManager {

}
