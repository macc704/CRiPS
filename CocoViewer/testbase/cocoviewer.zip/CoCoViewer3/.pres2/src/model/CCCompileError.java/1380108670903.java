package model;

public class CCCompileError {

}
