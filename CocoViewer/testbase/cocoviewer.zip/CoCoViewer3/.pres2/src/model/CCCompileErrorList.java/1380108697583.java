package model;

public class CCCompileErrorList {

}
