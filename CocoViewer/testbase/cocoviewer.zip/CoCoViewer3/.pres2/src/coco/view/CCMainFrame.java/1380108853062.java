package coco.view;

public class CCMainFrame {

}
