package coco.view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import org.jfree.chart.ChartColor;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.LineAndShapeRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import coco.model.CCCompileErrorList;

public class CCErrorElementButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CCCompileErrorList list;

	public CCErrorElementButton(CCCompileErrorList list) {
		super(list.getErrors().size() + " : " + list.getMessage());
		super.setBackground(Color.YELLOW);
		this.list = list;
		initialize(list);
	}

	private void initialize(final CCCompileErrorList list) {
		// �N���b�N���̓���̌���
		this.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CCGraphFrame frame = new CCGraphFrame();
				frame.initialize(list);
			}
		});
	}

	// �Ȃ񂩃C�}�C�`�Ȃ̂Ŏ����ō쐬�����O���t���g���\��E�b��ł�����
	private void makeGraph() {
		// ���{�ꂪ�����������Ȃ��e�[�}
		ChartFactory.setChartTheme(StandardChartTheme.createLegacyTheme());
		// �O���t�f�[�^��ݒ肷��
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		for (int i = 0; i < list.getErrors().size(); i++) {
			dataset.addValue(list.getErrors().get(i).getCorrectTime(), "�C������",
					Integer.toString(i));
		}

		// �O���t�̐���
		JFreeChart chart = ChartFactory.createLineChart(list.getMessage()
				+ "�̏C������", "�C����", "�C������", dataset, PlotOrientation.VERTICAL,
				true, true, false);

		// �w�i�F�̃Z�b�g
		chart.setBackgroundPaint(ChartColor.WHITE);

		CategoryPlot plot = chart.getCategoryPlot();
		LineAndShapeRenderer renderer = (LineAndShapeRenderer) plot
				.getRenderer();
		renderer.setSeriesPaint(0, ChartColor.RED);
		renderer.setSeriesStroke(0, new BasicStroke(2));
		renderer.setSeriesShapesVisible(0, true);

		ChartPanel cpanel = new ChartPanel(chart);
		cpanel.setBounds(20, 20, width - 50, height - 100);
		rootPanel.add(cpanel);
		add(rootPanel);
	}
}