package coco.view;

public class CCErrorElementButton {

}
