package coco.view;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

public class CCChartPanel extends ChartPanel {

	public CCChartPanel(JFreeChart chart) {

	}

}
