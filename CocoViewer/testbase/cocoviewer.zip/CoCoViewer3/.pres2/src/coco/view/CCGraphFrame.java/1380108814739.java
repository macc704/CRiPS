package coco.view;

public class CCGraphFrame {

}
