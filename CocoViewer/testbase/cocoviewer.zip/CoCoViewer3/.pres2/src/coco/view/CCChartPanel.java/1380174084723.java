package coco.view;

public class CCChartPanel {

}
