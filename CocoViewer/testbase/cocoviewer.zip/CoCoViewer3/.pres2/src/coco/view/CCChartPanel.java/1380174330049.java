package coco.view;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

public class CCChartPanel extends ChartPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CCChartPanel() {

	}

	public CCChartPanel(JFreeChart chart) {

	}

}
