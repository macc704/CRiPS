package coco;

public class CCMakeKindsDataStart {

}
