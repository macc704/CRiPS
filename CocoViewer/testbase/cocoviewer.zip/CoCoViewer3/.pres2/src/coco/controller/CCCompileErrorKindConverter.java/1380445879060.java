package coco.controller;

public class CCCompileErrorKindConverter {

}
