package coco.controller;

import java.io.IOException;

public class CCCompileErrorKindConverter extends CCFileLoader {

	@Override
	protected void separeteData(String line) throws IOException {
		// TODO Auto-generated method stub

	}

}
