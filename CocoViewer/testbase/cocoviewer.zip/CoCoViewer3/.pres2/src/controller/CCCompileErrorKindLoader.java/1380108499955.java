package controller;

public class CCCompileErrorKindLoader {

}
