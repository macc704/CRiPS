package controller;

public class CCCompileErrorLoader {

}
