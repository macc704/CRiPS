package controller;

public class CCCompileErrorMaker {

}
