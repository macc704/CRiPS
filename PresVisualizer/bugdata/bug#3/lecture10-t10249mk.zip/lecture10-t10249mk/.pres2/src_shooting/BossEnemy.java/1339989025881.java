import java.awt.Color;

import obpro.gui.BCanvas;

/*
 * �v���O�������F BossEnemy
 * �쐬�ҁF Kanuma Misa
 * 2012.6.18
 */
/**
 * �G�@��\������N���X
 */
public class BossEnemy extends AbstractEnemyAircraft {

	/*
	 * �v���O�������FRocket.java �쐬�ҁF �R���@�R�W ���P�b�g�̊G��`���N���X�ł��B ���؂�܂����B
	 */

	private Color color;
	private int size = 0;

	/**
	 * �R���X�g���N�^
	 */
	public BossEnemy(Color color, int x, int y, int size) {
		super(x, y, size, size);
		this.color = color;
		this.size = size;
	}

	// �}�`��`��
	public void draw(BCanvas canvas) {

		canvas.drawFillTriangle(color, size * 2 + getX(), getY(), size * 1.5
				+ getX(), size * 0.5 + getY(), size * 2.5 + getX(), size * 0.5
				+ getY());
		canvas.drawLine(color, size * 1.5 + getX(), size * 0.5 + getY(), size
				* 1.5 + getX(), size * 3.5 + getY());
		canvas.drawLine(color, size * 2.5 + getX(), size * 0.5 + getY(), size
				* 2.5 + getX(), size * 3.5 + getY());
		canvas.drawLine(color, size * 1.5 + getX(), size * 3.5 + getY(), size
				* 2.5 + getX(), size * 3.5 + getY());
		canvas.drawFillTriangle(color, size * 1.5 + getX(),
				size * 3.5 + getY(), size + getX(), size * 4 + getY(), size
						* 1.5 + getX(), size * 4 + getY());
		canvas.drawFillTriangle(color, size * 2.5 + getX(),
				size * 3.5 + getY(), size * 3 + getX(), size * 4 + getY(), size
						* 2.5 + getX(), size * 4 + getY());
		canvas.drawLine(color, size * 1.5 + getX(), size * 4 + getY(), size
				* 2.5 + getX(), size * 4 + getY());
		canvas.drawLine(color, size * 1.7 + getX(), size * 3.5 + getY(), size
				* 1.7 + getX(), size * 4 + getY());
		canvas.drawLine(color, size * 1.9 + getX(), size * 3.5 + getY(), size
				* 1.9 + getX(), size * 4 + getY());
		canvas.drawLine(color, size * 2.1 + getX(), size * 3.5 + getY(), size
				* 2.1 + getX(), size * 4 + getY());
		canvas.drawLine(color, size * 2.3 + getX(), size * 3.5 + getY(), size
				* 2.3 + getX(), size * 4 + getY());
		canvas.drawFillArc(color, size * 1.7 + getX(), size * 1.5 + getY(),
				size * 0.6, size * 0.6, 0, 360);

	}

}
