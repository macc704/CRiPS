import java.awt.Color;

import obpro.gui.BCanvas;

/**
 * �G�@��\������N���X
 */
public class AbstractEnemyAircraft extends ShootingCharacter {

	/**
	 * �R���X�g���N�^
	 */
	public AbstractEnemyAircraft(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	/**
	 * �P�X�e�b�v�̏���������
	 */
	public void processOneStep() {
		move(-5, 0);
	}

	/**
	 * �����̏���������
	 */
	private void processExplore() {
		if (liveState == EXPLODING) {
			explodingCount++;
			if (explodingCount == EXPLODING_ANIMATION_SIZE) {
				liveState = DEAD;
			}
		}
	}

	/**
	 * ��������i������ԂɑJ�ڂ���j
	 */
	public void explode() {
		if (liveState == ALIVE) {
			liveState = EXPLODING;
			explodingCount = 0;
		}
	}

	/**
	 * �e�Ƃ̏Փ˔��������
	 */
	public boolean intersects(Bullet bullet) {
		int bullet_leftX = bullet.getX();
		int bullet_rightX = bullet.getX() + bullet.getWidth();
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullet_topY = bullet.getY();
		int bullet_bottomY = bullet.getY() + bullet.getHeight();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();

		return (enemy_leftX < bullet_rightX && enemy_rightX > bullet_leftX
				&& enemy_topY < bullet_bottomY && enemy_bottomY > bullet_topY);
	}

	/**
	 * �G�Ƃ̏Փ˔��������
	 */
	public boolean intersects(Bullet bullet) {
		int bullet_leftX = bullet.getX();
		int bullet_rightX = bullet.getX() + bullet.getWidth();
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullet_topY = bullet.getY();
		int bullet_bottomY = bullet.getY() + bullet.getHeight();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();

		return (enemy_leftX < bullet_rightX && enemy_rightX > bullet_leftX
				&& enemy_topY < bullet_bottomY && enemy_bottomY > bullet_topY);
	}

	/**
	 * �`��
	 */
	public void draw(BCanvas canvas) {
		// ���W�����߂�
		// �{��
		int bodyHeight = getHeight() * 2 / 5;
		int bodyY = getY() + bodyHeight;
		int bodyWidth = getWidth() * 10 / 11;

		// ��������
		int verticalWingX = getX() + getWidth() * 5 / 11;

		// ��������
		int tailWingX = getX() + getWidth() * 10 / 11;
		int tailWingY = getY() + getHeight() * 3 / 5;
		int tailWingWidth = getWidth() / 11;
		int tailWingHeight = getHeight() / 5;

		// �R�b�N�s�b�g
		int cockpitX = getX() + tailWingWidth;
		int cockpitY = bodyY - tailWingWidth;
		int cockpitWidth = getWidth() * 2 / 11;

		// �嗃
		int mainWingX1 = getX() + getWidth() * 3 / 11;
		int mainWingX2 = getX() + getWidth() * 8 / 11;

		// �{�̂�`��
		drawFillRectangle(canvas, Color.BLACK, getX(), bodyY, bodyWidth,
				bodyHeight);
		canvas.drawFillArc(Color.GRAY, cockpitX, cockpitY, cockpitWidth,
				cockpitWidth, 0, 180);// �R�b�N�s�b�g

		// ����������`��
		drawFillRectangle(canvas, Color.BLUE, tailWingX, tailWingY,
				tailWingWidth, tailWingHeight);

		// ����������`��
		canvas.drawFillTriangle(Color.RED, verticalWingX, bodyY, tailWingX,
				getY(), tailWingX, bodyY);

		// �嗃��`��
		canvas.drawFillTriangle(Color.CYAN, mainWingX1, tailWingY, mainWingX2,
				tailWingY, tailWingX, getY() + getHeight());
	}

	/**
	 * �l�p��`�悷��(�h��Ԃ�)
	 */
	private void drawFillRectangle(BCanvas canvas, Color color, int x, int y,
			int width, int height) {
		canvas.drawFillTriangle(color, x, y, x + width, y, x + width, y
				+ height);
		canvas.drawFillTriangle(color, x, y, x, y + height, x + width, y
				+ height);
	}

}