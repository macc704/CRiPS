import java.awt.Color;

import obpro.cui.Random;
import obpro.gui.BCanvas;

/**
 * �G�@��\������N���X
 */
public class AbstractEnemyAircraft extends ShootingCharacter {

	// �萔
	protected final int ALIVE = 1;
	private final int EXPLODING = 2;
	private final int DEAD = 3;

	private final int EXPLODING_ANIMATION_COUNT = 10;

	// ���
	private int liveState = ALIVE;
	private int explodingCount = 0;

	/**
	 * �R���X�g���N�^
	 */
	public AbstractEnemyAircraft(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	/**
	 * 1�R�}�̏������s��
	 */
	public void processOneStep() {
		move(-5, 0);
		if (liveState == EXPLODING) {
			processExplode();
		}
	}

	private void processExplode() {
		explodingCount++;
		if (explodingCount == EXPLODING_ANIMATION_COUNT) {
			liveState = DEAD;
		}
	}

	public void explode() {
		if (liveState == ALIVE) {
			liveState = EXPLODING;
			explodingCount = 0;
		}
	}

	/**
	 * �e�Ƃ̏Փ˔��������
	 */
	public boolean intersects(Bullet bullet) {
		int bullet_leftX = bullet.getX();
		int bullet_rightX = bullet.getX() + bullet.getWidth();
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullet_topY = bullet.getY();
		int bullet_bottomY = bullet.getY() + bullet.getHeight();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();

		return (enemy_leftX < bullet_rightX && enemy_rightX > bullet_leftX
				&& enemy_topY < bullet_bottomY && enemy_bottomY > bullet_topY);
	}

	/**
	 * �G�@�Ƃ̏Փ˔��������
	 */
	public boolean intersects(PlayerAircraft player) {
		int player_leftX = player.getX();
		int player_rightX = player.getX() + player.getWidth();
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int player_topY = player.getY();
		int player_bottomY = player.getY() + player.getHeight();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();

		return (enemy_leftX < player_rightX && enemy_rightX > player_leftX
				&& enemy_topY < player_bottomY && enemy_bottomY > player_topY);
	}

	/**
	 * ������`�悷��
	 */
	public void drawExplosion(BCanvas canvas) {
		// �΂̋ʂ̐������߂�
		int fireCount = explodingCount * 4;// �J�E���g���̂S�{�i���X�ɑ�����j

		// �΂̋ʂ�`�悷��
		for (int i = 0; i < fireCount; i++) {
			int fireX = getX() + Random.getInt(getWidth());
			int fireY = getY() + Random.getInt(getHeight());
			drawFire(canvas, fireX, fireY);
		}
	}

	/**
	 * �΂̋ʂ�`�悷��
	 */
	public void drawFire(BCanvas canvas, int x, int y) {
		canvas.drawFillArc(Color.RED, x, y, 20, 20, 0, 360);
		canvas.drawFillArc(Color.MAGENTA, x + 2, y + 2, 16, 16, 0, 360);
		canvas.drawFillArc(Color.WHITE, x + 1, y + 1, 14, 14, 0, 360);
		canvas.drawFillArc(Color.RED, x + 8, y + 1, 3, 3, 0, 360);
		canvas.drawFillArc(Color.RED, x + 2, y + 8, 3, 3, 0, 360);
		canvas.drawFillArc(Color.RED, x + 10, y + 8, 2, 3, 0, 360);
		canvas.drawFillArc(Color.RED, x, y + 1, 2, 2, 0, 360);
		canvas.drawFillArc(Color.RED, x + 15, y + 18, 2, 2, 0, 360);
	}

	/**
	 * �l�p��`�悷��(�h��Ԃ�)
	 */
	public void drawFillRectangle(BCanvas canvas, Color color, int x, int y,
			int width, int height) {
		canvas.drawFillTriangle(color, x, y, x + width, y, x + width, y
				+ height);
		canvas.drawFillTriangle(color, x, y, x, y + height, x + width, y
				+ height);
	}

}
