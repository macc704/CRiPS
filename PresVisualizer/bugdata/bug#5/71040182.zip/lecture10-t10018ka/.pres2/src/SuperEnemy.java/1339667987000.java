public class SuperEnemy extends AbstractEnemyAircraft {

	public SuperEnemy(int x, int y, int width, int height) {
		super(x, y, width, height);
		// Abstract����̌p��

	}

}
