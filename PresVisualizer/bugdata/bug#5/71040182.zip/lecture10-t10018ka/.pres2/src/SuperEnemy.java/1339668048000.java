public class SuperEnemy extends AbstractEnemyAircraft {

	public SuperEnemy(int x, int y, int width, int height) {
		super(x, y, width, height);
		// Abstract����̌p��
	}

	// �萔
	private final int ALIVE = 1;
	private final int DEAD = 2;

	// ���
	private int liveState = ALIVE;

}
