import obpro.gui.BCanvas;

public class SuperEnemy extends AbstractEnemyAircraft {

	public SuperEnemy(int x, int y, int width, int height) {
		super(x, y, width, height);
		// Abstract����̌p��
	}

	// �萔
	private final int ALIVE = 1;
	private final int DEAD = 2;

	// ���
	private int liveState = ALIVE;

	/**
	 * �P�X�e�b�v�̏���������
	 */
	public void processOneStep() {
		move(-2, 0);
	}

	public void draw(BCanvas canvas) {
		if (liveState == ALIVE) {
			drawSuperEnemy(canvas);
		}
	}

	public void kieru() {
		liveState = DEAD;
	}

	/**
	 * �`��
	 */
	public void drawSuperEnemy(BCanvas canvas) {

	}

}
