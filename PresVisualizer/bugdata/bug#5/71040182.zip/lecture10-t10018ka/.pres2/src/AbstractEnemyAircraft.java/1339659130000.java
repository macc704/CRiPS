public class AbstractEnemyAircraft extends ShootingCharacter {

}
