public class AbstractEnemyAircraft extends ShootingCharacter {

	public AbstractEnemyAircraft(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	// ShootingCharacter����̒�`

	// �G�ƒe�̏Փ˔���
	public boolean intersects(Bullet bullet) {
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullet_leftX = bullet.getX();
		int bullet_rightX = bullet.getX() + bullet.getWidth();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();
		int bullet_topY = bullet.getY();
		int bullet_bottomY = bullet.getY() + bullet.getHeight();

		return (bullet_leftX < enemy_rightX && bullet_rightX > enemy_leftX
				&& bullet_topY < enemy_bottomY && bullet_bottomY > enemy_topY);

	}

	// �v���C���[�Ƃ̏Փ˔���
	public boolean intersects2(PlayerAircraft player) {
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullet_leftX = player.getX();
		int bullet_rightX = player.getX() + player.getWidth();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();
		int bullet_topY = player.getY();
		int bullet_bottomY = player.getY() + player.getHeight();

		return (bullet_leftX < enemy_rightX && bullet_rightX > enemy_leftX
				&& bullet_topY < enemy_bottomY && bullet_bottomY > enemy_topY);

	}

}
