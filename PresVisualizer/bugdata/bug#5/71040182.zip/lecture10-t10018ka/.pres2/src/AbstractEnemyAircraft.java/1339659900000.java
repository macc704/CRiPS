public class AbstractEnemyAircraft extends ShootingCharacter {

	public AbstractEnemyAircraft(int x, int y, int width, int height) {
		super(x, y, width, height);
		// ShootingCharacter����̒�`
		
		// �G�Ƃ̏Փ˔���@enemy��
		public boolean intersect1(Bullet bullet) {
			int enemy_leftX = this.getX();
			int enemy_rightX = this.getX() + this.getWidth();
			int bullet_leftX = bullet.getX();
			int bullet_rightX = bullet.getX() + bullet.getWidth();
			int enemy_topY = this.getY();
			int enemy_bottomY = this.getY() + this.getHeight();
			int bullet_topY = bullet.getY();
			int bullet_bottomY = bullet.getY() + bullet.getHeight();

			return (bullet_leftX < enemy_rightX && bullet_rightX > enemy_leftX
					&& bullet_topY < enemy_bottomY && bullet_bottomY > enemy_topY);
		}
	}
}
