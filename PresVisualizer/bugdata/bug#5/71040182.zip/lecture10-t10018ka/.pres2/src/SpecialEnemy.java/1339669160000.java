public class SpecialEnemy extends AbstractEnemyAircraft {

	public SpecialEnemy(int x, int y, int width, int height) {
		super(x, y, width, height);
		// Abstract�̌p��

	}

}
