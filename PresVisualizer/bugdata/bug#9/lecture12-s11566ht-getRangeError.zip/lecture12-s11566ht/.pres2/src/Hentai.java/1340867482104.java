
public class Hentai {

}
