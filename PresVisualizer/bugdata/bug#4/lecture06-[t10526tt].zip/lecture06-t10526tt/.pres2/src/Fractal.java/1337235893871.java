import obpro.turtle.Turtle;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class Fractal extends Turtle {

	// �N������
	public static void main(String[] args) {
		Turtle.startTurtle(new Fractal());
	}

	// �^�[�g���𓮂�������
	public void start() {
		window.size(500, 500);
		warp(250, 100);

		drawY(20);

	}

	void drawY(int length) {
		if (length < 5) {
			return;
		}

		rt(180);

		fd(length);

		lt(90);
		fd(length * 3 / 2);
		rt(90);
		fd(length);
		drawY(length / 2);
		bk(length);
		lt(90);
		bk(length * 3 / 2);
		rt(90);

		rt(90);
		fd(length * 3 / 2);
		lt(90);
		fd(length);
		drawy(length / 2);
		bk(length);
		rt(90);
		bk(length * 3 / 2);

	}
}
