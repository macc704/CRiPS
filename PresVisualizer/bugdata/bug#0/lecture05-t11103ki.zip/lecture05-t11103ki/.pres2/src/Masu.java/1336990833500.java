import obpro.turtle.Turtle;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class Masu extends Turtle {

	// �N������
	public static void main(String[] args) {
		Turtle.startTurtle(new Masu());
	}

	// �^�[�g���𓮂�������
	public void start() {
		rt(90);

		drawMasu(2, 3, 50);
	}

	void drawMasu(int row, int col, int size) {

		for (int j = 1; j <= row; j++) {

			int i;
			i = 1;
			while (i <= col) {
				drawSquare();
				i++;
			}

			rt(90);
			fd(size);
			rt(90);
			fd(size * col);
			rt(180);

		}
	}

	/*
	 * int i; i = 1; while (i < 3) {
	 * 
	 * fd(50); fd(50); lt(90); fd(50); fd(50); fd(50); lt(90);
	 * 
	 * i++;
	 * 
	 * } lt(90);
	 * 
	 * int j; if (j <= 2) { fd(50); j++; }
	 */

	void drawSquare() {
		int i;
		i = 1;
		while (i <= 4) {
			fd(50);
			rt(90);
			i++;
		}
		fd(50);
	}
}