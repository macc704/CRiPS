public class AbstractEnemyAircraft extends ShootingCharacter {

	// �R���X�g���N�^
	public AbstractEnemyAircraft(int x, int y, int width, int height) {
		super(x, y, width, height);
	}

	//
	public boolean intersects(Bullet bullets) {
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int bullets_leftX = bullets.getX();
		int bullets_rightX = bullets.getX() + bullets.getWidth();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();
		int bullets_topY = bullets.getY();
		int bullets_bottomY = bullets.getY() + bullets.getHeight();

		return (bullets_leftX < enemy_rightX && bullets_rightX > enemy_leftX
				&& bullets_topY < enemy_bottomY && bullets_bottomY > enemy_topY);
	}

	public boolean intersects(PlayerAircraft player) {
		int enemy_leftX = this.getX();
		int enemy_rightX = this.getX() + this.getWidth();
		int player_leftX = player.getX();
		int player_rightX = player.getX() + player.getWidth();
		int enemy_topY = this.getY();
		int enemy_bottomY = this.getY() + this.getHeight();
		int player_topY = player.getY();
		int player_bottomY = player.getY() + player.getHeight();

		return (player_leftX < enemy_rightX && player_rightX > enemy_leftX
				&& player_topY < enemy_bottomY && player_bottomY > enemy_topY);
	}

}
